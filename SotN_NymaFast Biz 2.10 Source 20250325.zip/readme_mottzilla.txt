This contains just the changed source files for BizHawk 2.10 to build the fast core for SotN.
You must first be able to build the waterbox cores already. Then you can update your source
tree with these files to apply all the changes and then rebuild the core.

Also after you build the core you should run 'zstd shock.wbx' to compress to shock.wbx.zst

These source changes are the same changes as the core for BizHawk 2.8 & BizHawk 2.9.1


-- Standard Readme Below --

2025-03-25

First make a copy of your Bizhawk Folder as the new core should only run Castlevania SotN and not other PS1 games.
Running other games might be possible but is not recommended. 

shock.wbx.zst is a replacement Nymashock core. You must rename or remove your original file which will be in
your Bizhawk\DLL folder. It will be named shock.wbx.zst

Then place the new shock.wbx.zst in the DLL folder.

Core Changes by SonicDreamcaster & MottZilla

* RAM Expansion (for future mods)
* CD Load Speed Increase
* Timing changes (to reduce or eliminate slowdowns)

